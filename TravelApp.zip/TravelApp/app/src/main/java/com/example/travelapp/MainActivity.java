package com.example.travelapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initialize button
        Button startProgram = findViewById(R.id.startProgram);
        startProgram.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.startProgram:
            default:
                setContentView(R.layout.get_input);
                Button goBack = findViewById(R.id.goBackButton);
                goBack.setOnClickListener(this);
                break;
            case R.id.goBackButton:
                setContentView(R.layout.activity_main);
                Button startProgram = findViewById(R.id.startProgram);
                startProgram.setOnClickListener(this);
        }
    }
}